export default function ApplicationLogo(props) {
    return (
       <img src="/img/msgs.png" width={30} height={30} />
    );
}
