<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH M:\messanger\clone\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>